#  -*-coding:utf8 -*-

"""
Created on 2021 7 11

@author: 陈雨
"""

import tensorflow as tf
from dataset import tokenizer
import settings
import utils

# 加载训练好的模型
model = tf.keras.models.load_model(settings.BEST_MODEL_PATH)
print()
print()

print('----------随机生成一首诗----------')

# 随机生成一首诗
print(utils.generate_random_poetry(tokenizer, model))
print()
print(utils.generate_random_poetry(tokenizer, model))
print()
print(utils.generate_random_poetry(tokenizer, model))
print()
print()

print('----------随机生成剩余部分----------')

# 给出部分信息的情况下，随机生成剩余部分
print(utils.generate_random_poetry(tokenizer, model, s='南风正送君'))
print()
print(utils.generate_random_poetry(tokenizer, model, s='床前明月光'))
print()
print(utils.generate_random_poetry(tokenizer, model, s='君问归期未有期'))
print()
print()

print('----------随机生成藏头诗----------')

# 生成藏头诗
print(utils.generate_acrostic(tokenizer, model, head='海阔天空'))
print()
print(utils.generate_acrostic(tokenizer, model, head='君临城下'))
print()
print(utils.generate_acrostic(tokenizer, model, head='景向谁依'))
print()
print(utils.generate_acrostic(tokenizer, model, head='谁人闻香来化蝶向景依'))
print()
print(utils.generate_acrostic(tokenizer, model, head='博君一肖'))
print()
print(utils.generate_acrostic(tokenizer, model, head='小雨最棒'))
